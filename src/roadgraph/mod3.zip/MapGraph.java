package roadgraph;


import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.LinkedList;
import java.util.Queue;
import java.util.PriorityQueue;

import geography.GeographicPoint;
import util.GraphLoader;

/**
 * @author UCSD MOOC development team and YOU
 * 
 * A class which represents a graph of geographic locations
 * Nodes in the graph are intersections between 
 *
 */

public class MapGraph {
	//TODO: Add your member variables here in WEEK 3

    private int numVertices;
    private int numEdges;
    private HashMap<GeographicPoint, List<Road>> intersectionsMap;
    private Set<GeographicPoint> intersections;

	/** 
	 * Create a new empty MapGraph 
	 */
	public MapGraph()
	{
		// TODO: Implement in this constructor in WEEK 3
        numEdges = 0;
        numEdges = 0;
        intersectionsMap = new HashMap<GeographicPoint, List<Road>>();
        intersections = new HashSet<GeographicPoint>();
	}
	

    /**
     * Print the graph by listing each vertex and its adjacent vertices.
     */
    public void printGraph() {
        for (GeographicPoint vertex : intersectionsMap.keySet()) {
            System.out.print(vertex + ": ");
            for (Road road : intersectionsMap.get(vertex)) {
                System.out.print("(" + road.getDestination() + ", " + road.getRoadName() + ", " + road.getRoadType() + ", " + road.getLength() + "), ");
            }
            System.out.println();
        }
    }

    /**
     * Returns a list of geographic points that are neighbors of a given point in the graph.
     * Throws an IllegalArgumentException if the given point is not in the graph.
     * 
     * @param from the point to get neighbors for
     * @return a list of geographic points that are neighbors of the given point
     */
    public List<GeographicPoint> getNeighbors(GeographicPoint from) throws IllegalArgumentException 
    {
        List<GeographicPoint> neighbors = new ArrayList<GeographicPoint>();
        List<Road> roads = intersectionsMap.get(from);
        if (roads == null) {
            throw new IllegalArgumentException("The given point is not in the graph.");
        }
        for (Road road : roads) {
            GeographicPoint neighbor = road.getDestination(); 
            neighbors.add(neighbor);
        }
        return neighbors;
    }

	/**
	 * Get the number of vertices (road intersections) in the graph
	 * @return The number of vertices in the graph.
	 */
	public int getNumVertices()
	{
		//TODO: Implement this method in WEEK 3
		return numVertices;
	}
	
	/**
	 * Return the intersections, which are the vertices in this graph.
	 * @return The vertices in this graph as GeographicPoints
	 */
	public Set<GeographicPoint> getVertices()
	{
		//TODO: Implement this method in WEEK 3
		return intersections;
	}
	
	/**
	 * Get the number of road segments in the graph
	 * @return The number of edges in the graph.
	 */
	public int getNumEdges()
	{
		//TODO: Implement this method in WEEK 3
		return numEdges;
	}

	
	
	/** Add a node corresponding to an intersection at a Geographic Point
	 * If the location is already in the graph or null, this method does 
	 * not change the graph.
	 * @param location  The location of the intersection
	 * @return true if a node was added, false if it was not (the node
	 * was already in the graph, or the parameter is null).
	 */
	public boolean addVertex(GeographicPoint location)
	{
		// TODO: Implement this method in WEEK 3
        // if the location is null or is already on the Graph do nothing
        if (intersections.contains(location) || location == null)
            return false;

        // add the location to the intersections set and an empty ArrayList to the intersectionsMap
        intersections.add(location);
        intersectionsMap.put(location, new ArrayList<Road>());
        numVertices++;
        return true;
	}
	
	/**
	 * Adds a directed edge to the graph from pt1 to pt2.  
	 * Precondition: Both GeographicPoints have already been added to the graph
	 * @param from The starting point of the edge
	 * @param to The ending point of the edge
	 * @param roadName The name of the road
	 * @param roadType The type of the road
	 * @param length The length of the road, in km
	 * @throws IllegalArgumentException If the points have not already been
	 *   added as nodes to the graph, if any of the arguments is null,
	 *   or if the length is less than 0.
	 */
    public void addEdge(GeographicPoint from, GeographicPoint to, String roadName,
            String roadType, double length) throws IllegalArgumentException {
        try {
            if (length <= 0 || roadType == null || roadName == null) {
                throw new IllegalArgumentException("Invalid argument(s) for addEdge");
            }

            List<Road> neighbors = intersectionsMap.get(from);
            if (neighbors == null) {
                throw new IllegalArgumentException("Starting point not in graph: " + from);
            }
            if (!intersections.contains(to)) {
                throw new IllegalArgumentException("Ending point not in graph: " + to);
            }
            Road road = new Road(roadName, roadType, length, to);
            if (!intersectionsMap.containsKey(from)) {
                intersectionsMap.put(from, new ArrayList<Road>());
            }
            intersectionsMap.get(from).add(road);
            numEdges++;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid argument for addEdge", e);
        } 
    }
	

	/** Find the path from start to goal using breadth first search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest (unweighted)
	 *   path from start to goal (including both start and goal).
	 */
	public List<GeographicPoint> bfs(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
        Consumer<GeographicPoint> temp = (x) -> {};
        return bfs(start, goal, temp);
	}
	/**
     * Construct the path from start to goal using a parentMap created during a search algorithm.
     *
     * @param start the starting point of the path
     * @param goal the goal point of the path
     * @param parentMap a HashMap that maps each point to its parent in the search algorithm
     * @return a LinkedList of GeographicPoints representing the path from start to goal
     */
     private List<GeographicPoint> constructPath(GeographicPoint start, 
                                                 GeographicPoint goal, 
                                                 HashMap<GeographicPoint, GeographicPoint> parentMap) 
    {
        if (parentMap == null) 
        {
            return null;
        }

        LinkedList<GeographicPoint> path = new LinkedList<>();
        GeographicPoint curr = goal;
        while (!curr.equals(start)) {
            path.addFirst(curr);
            curr = parentMap.get(curr);
        }
        path.addFirst(start);
        return path;
    }

	/** Find the path from start to goal using breadth first search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
	 * @return The list of intersections that form the shortest (unweighted)
	 *   path from start to goal (including both start and goal).
	 */
	public List<GeographicPoint> bfs(GeographicPoint start, 
			 					     GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
	{
		// TODO: Implement this method in WEEK 3
	    // Create a visited set to keep track of the visited nodes,
        // and a queue to store the nodes to be explored.
        HashSet<GeographicPoint> visited = new HashSet<GeographicPoint>();
        Queue<GeographicPoint> queue = new LinkedList<GeographicPoint>();
        HashMap<GeographicPoint, GeographicPoint> parentMap = new HashMap<GeographicPoint, GeographicPoint>();
        // Add the start node to the queue and mark it as visited.
        queue.add(start);
        // While the queue is not empty:
        while(!queue.isEmpty())
        {
            // a. Remove the first node from the queue and mark it as visited.
            GeographicPoint head = queue.poll();

            // Call the nodeSearched function with the current node's coordinates.
            nodeSearched.accept(head);

            visited.add(head);
            // b. If this node is the goal node, return the path to it.
            if (head.equals(goal)) {
                return constructPath(start, goal, parentMap);
            }
            else{
                // c. Otherwise, for each neighbor of the current node that has not been visited:
                for (GeographicPoint neighbor : getNeighbors(head))
                {
                    // i. Add the neighbor to the queue.
                    queue.add(neighbor);
                    // ii. Mark the neighbor as visited.
                    visited.add(neighbor);
                    // iii. Add the current node to the neighbor's path.
                    parentMap.put(neighbor, head);
                }
            }
        }

        // iv. Call the nodeSearched function with the neighbor's coordinates.
        // If the goal node is not found, return null or an empty path.	
        // Hook for visualization.  See writeup.
        //nodeSearched.accept(next.getLocation());
		return null;
	}
	

	/** Find the path from start to goal using Dijkstra's algorithm
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> dijkstra(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
		// You do not need to change this method.
        Consumer<GeographicPoint> temp = (x) -> {};
        return dijkstra(start, goal, temp);
	}
	
	/** Find the path from start to goal using Dijkstra's algorithm
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
    public List<GeographicPoint> dijkstra(GeographicPoint start, GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
    {
        // Initializing
        PriorityQueue<Intersection> pq = new PriorityQueue<Intersection>();
        HashSet<GeographicPoint> visited = new HashSet<GeographicPoint>();
        HashSet<Intersection> Intersections = new HashSet<Intersection>();
        HashMap<GeographicPoint, GeographicPoint> parentMap = new HashMap<GeographicPoint, GeographicPoint>();

        // set the start distance to 0
        // Initialze : pq, visited, parentMap, Intersections
        // enque start {S, 0} into pq
        // add start to Intersections
        Intersection startingIntersection = new Intersection(start, 0);
        pq.add(startingIntersection);
        Intersections.add(startingIntersection);

        // as long as pq is not empty
        while (!pq.isEmpty())
        {

        // decue curr from the front of the queue
        Intersection currentIntersection = pq.poll();
        
        // get the key node of the current Intersection And its distance
        GeographicPoint currentNode = currentIntersection.getStart();
        double currentNodeDistance = currentIntersection.getDistance();

        // if curr is not visited
        if (!visited.contains(currentNode))
        {
            // add curr to visited 
            visited.add(currentNode);
            nodeSearched.accept(currentNode); // Call the nodeSearched consumer
        }

        // if curr == goal 
        if (currentNode.equals(goal))
        {
            // return parentMap
            return constructPath(start, goal, parentMap);
        }


        // get the list of roads out of curr
        List<Road> currentRoads = intersectionsMap.get(currentNode);

        // for each neighbor of currentNode
        for (Road currentRoad : currentRoads)
        {
            // get the neighbor from the road
            GeographicPoint neighbor = currentRoad.getDestination();

            // That is not visited
            if (!visited.contains(neighbor))
            {
            // if pathThrough (roadLength + The distanceOfTheintersectionOf currentNodeneighbor < neighbor.destance
                double pathThrough = currentRoad.getLength() + currentNodeDistance;

                // get the neighbor distance 
                Intersection neighborIntersection = getNeighborIntersection(neighbor, Intersections);
                double neighborIntersectionDistance = neighborIntersection.getDistance();

                if (pathThrough < neighborIntersectionDistance)
                {
                    // make neighbor distance = pathThrough
                    neighborIntersection.setDistance(pathThrough);
                    // make parentMap(curr, neighbor)
                    parentMap.put(neighbor, currentNode);
                    // enque {neighbor, neighbor.distance()}
                    pq.add(neighborIntersection);
                }
            }

        }

        }

        return null;
    }

    /**
     * Finds an intersection in the set of intersections that starts from the given geographic point and returns it.
     * If no such intersection exists in the set, a new intersection is created starting from the given geographic point,
     * added to the set of intersections, and returned.
     *
     * @param neighbor the starting geographic point of the road segment leading to the neighbor intersection
     * @param intersections the set of intersections to search for the neighbor intersection
     * @return the neighbor intersection starting from the given geographic point
     */
    private Intersection getNeighborIntersection(GeographicPoint neighbor, HashSet<Intersection> intersections) {
        for (Intersection intersection : intersections) {
            if (intersection.getStart().equals(neighbor)) {
                return intersection;
            }
        }

        // If no intersection found, create a new one with the given neighbor as the start and add it to the set
        Intersection newIntersection = new Intersection(neighbor);
        intersections.add(newIntersection);
        return newIntersection;
    }


	/** Find the path from start to goal using A-Star search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> aStarSearch(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
        Consumer<GeographicPoint> temp = (x) -> {};
        return aStarSearch(start, goal, temp);
	}
	
    /** Find the path from start to goal using A-Star search
     * 
     * @param start The starting location
     * @param goal The goal location
     * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
     * @return The list of intersections that form the shortest path from 
     *   start to goal (including both start and goal).
     */
    public List<GeographicPoint> aStarSearch(GeographicPoint start, 
                                             GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
    {
        // Initializing
        PriorityQueue<Intersection> pq = new PriorityQueue<Intersection>();
        HashSet<GeographicPoint> visited = new HashSet<GeographicPoint>();
        HashSet<Intersection> Intersections = new HashSet<Intersection>();
        HashMap<GeographicPoint, GeographicPoint> parentMap = new HashMap<GeographicPoint, GeographicPoint>();

        // set the start distance to 0
        // Initialze : pq, visited, parentMap, Intersections
        // enque start {S, 0} into pq
        // add start to Intersections
        Intersection startingIntersection = new Intersection(start, 0);
        pq.add(startingIntersection);
        Intersections.add(startingIntersection);

        // as long as pq is not empty
        while (!pq.isEmpty())
        {

            // decue curr from the front of the queue
            Intersection currentIntersection = pq.poll();
            
            // get the key node of the current Intersection And its distance
            GeographicPoint currentNode = currentIntersection.getStart();
            double currentNodeDistance = currentIntersection.getDistance();

            // if curr is not visited
            if (!visited.contains(currentNode))
            {
                // add curr to visited 
                visited.add(currentNode);
                nodeSearched.accept(currentNode); // Call the nodeSearched consumer
            }

            // if curr == goal 
            if (currentNode.equals(goal))
            {
                // return parentMap
                return constructPath(start, goal, parentMap);
            }


            // get the list of roads out of curr
            List<Road> currentRoads = intersectionsMap.get(currentNode);

            // for each neighbor of currentNode
            for (Road currentRoad : currentRoads)
            {
                // get the neighbor from the road
                GeographicPoint neighbor = currentRoad.getDestination();

                // That is not visited
                if (!visited.contains(neighbor))
                {
                    // if pathThrough (roadLength + The distanceOfTheintersectionOf currentNodeneighbor < neighbor.destance
                    double pathThrough = currentRoad.getLength() + currentNodeDistance;

                    // get the neighbor distance 
                    Intersection neighborIntersection = getNeighborIntersection(neighbor, Intersections);
                    double neighborIntersectionDistance = neighborIntersection.getDistance();

                    if (pathThrough < neighborIntersectionDistance)
                    {
                        // make neighbor distance = pathThrough
                        neighborIntersection.setDistance(pathThrough);
                        // make parentMap(curr, neighbor)
                        parentMap.put(neighbor, currentNode);
                        // enque {neighbor, neighbor.distance() + h(neighbor)}
                        pq.add(new Intersection(neighbor, pathThrough + neighbor.distance(goal)));
                    }
                }

            }

        }

        return null;
    }

	
	
	public static void main(String[] args)
	{
		System.out.print("Making a new map...");
		MapGraph firstMap = new MapGraph();
		System.out.print("DONE. \nLoading the map...");
		GraphLoader.loadRoadMap("data/testdata/simpletest.map", firstMap);
		System.out.println("DONE.");
		
		// You can use this method for testing.  
		
		
		/* Here are some test cases you should try before you attempt 
		 * the Week 3 End of Week Quiz, EVEN IF you score 100% on the 
		 * programming assignment.
		 */
		
		MapGraph simpleTestMap = new MapGraph();
		GraphLoader.loadRoadMap("data/testdata/simpletest.map", simpleTestMap);
		
		GeographicPoint testStart = new GeographicPoint(1.0, 1.0);
		GeographicPoint testEnd = new GeographicPoint(8.0, -1.0);
		
		System.out.println("Test 1 using simpletest: Dijkstra should be 9 and AStar should be 5");
		List<GeographicPoint> testroute = simpleTestMap.dijkstra(testStart,testEnd);
		List<GeographicPoint> testroute2 = simpleTestMap.aStarSearch(testStart,testEnd);
		
		
		MapGraph testMap = new MapGraph();
		GraphLoader.loadRoadMap("data/maps/utc.map", testMap);
		
		// A very simple test using real data
		testStart = new GeographicPoint(32.869423, -117.220917);
		testEnd = new GeographicPoint(32.869255, -117.216927);
		System.out.println("Test 2 using utc: Dijkstra should be 13 and AStar should be 5");
		testroute = testMap.dijkstra(testStart,testEnd);
		testroute2 = testMap.aStarSearch(testStart,testEnd);
		
		
		// A slightly more complex test using real data
		testStart = new GeographicPoint(32.8674388, -117.2190213);
		testEnd = new GeographicPoint(32.8697828, -117.2244506);
		System.out.println("Test 3 using utc: Dijkstra should be 37 and AStar should be 10");
		testroute = testMap.dijkstra(testStart,testEnd);
		testroute2 = testMap.aStarSearch(testStart,testEnd);
		
		
		
		/* Use this code in Week 3 End of Week Quiz */
		MapGraph theMap = new MapGraph();
		System.out.print("DONE. \nLoading the map...");
		GraphLoader.loadRoadMap("data/maps/utc.map", theMap);
		System.out.println("DONE.");

		GeographicPoint start = new GeographicPoint(32.8648772, -117.2254046);
		GeographicPoint end = new GeographicPoint(32.8660691, -117.217393);
		
		
		List<GeographicPoint> route = theMap.dijkstra(start,end);
		List<GeographicPoint> route2 = theMap.aStarSearch(start,end);

	
		
	}
	
}
